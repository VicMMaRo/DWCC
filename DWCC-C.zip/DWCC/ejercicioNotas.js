let nota = 6;
if (nota < 0 || nota > 10)
{
    console.log("Nota fuera de rango");
}

else if (nota < 5)
{
    console.log("Suspenso");
}

else if (nota < 6)
{
   console.log("Aprobado");
}
else if (nota < 7)
{
    console.log("Bien");
}

else if (nota < 9)
{
    console.log("Notable");
}

else if (nota < 10)
{
    console.log("Sobresaliente");
}

else if (nota === 10)
{
    console.log("Matrícula");
}