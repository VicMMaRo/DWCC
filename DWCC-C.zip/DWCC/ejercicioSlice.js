let comidas = ["Coliflor", "Ensalada", "Pasta", "Bacalao", "Pizza"];
let podio = comidas.slice(0,3);

console.log(comidas);
console.log(podio);