class Pokemon {
  #hp;

  constructor(nombre, tipo, hp) {
    this.nombre = nombre;
    this.tipo = tipo;
    this.#hp = hp;
  }

  atacar(objetivo) {
    console.log(`${this.nombre} ataca a ${objetivo.nombre}!`);
  }

  recibirDano(dano) {
    this.#hp -= dano;
    if (this.#hp < 0) this.#hp = 0;
    console.log(`${this.nombre} ahora tiene ${this.#hp} HP.`);
  }

  getHP() {
    return this.#hp;
  }

  static lema() {
    console.log("¡Gotta catch ’em all! 🏆");
  }
}

class Pikachu extends Pokemon {
  constructor(hp) {
    super("Pikachu", "Eléctrico", hp);
  }

  atacar(objetivo) {
    console.log(`${this.nombre} lanza un Rayo⚡⚡contra ${objetivo.nombre}!`);
    objetivo.recibirDano(25);
  }
}

class Charmander extends Pokemon {
  constructor(hp) {
    super("Charmander", "Fuego", hp);
  }

  atacar(objetivo) {
    console.log(
      `${this.nombre} lanza una Llamarada 🔥🔥 contra ${objetivo.nombre}!`
    );
    objetivo.recibirDano(30);
  }
}

let pikachu = new Pikachu(100);
let charmander = new Charmander(100);

pikachu.atacar(charmander);
charmander.atacar(pikachu);
