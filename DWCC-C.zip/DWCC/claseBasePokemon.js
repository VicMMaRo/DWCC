class Pokemon {
  nombre;
  #nivel;
  tipo;

  constructor(nombre, nivel, tipo) {
    this.nombre = nombre;
    this.#nivel = nivel;
    this.tipo = tipo;
  }

  sayMyName() {
    console.log(this.nombre);
  }

  setNivel(nivel) {
    this.#nivel = nivel;
  }

  getNivel() {
    return this.#nivel;
  }
}

let poke1 = new Pokemon("Pikachu", 25, "Eléctrico");
let poke2 = new Pokemon("Caterpie", 5, "Bicho");
console.log(poke1.getNivel());
console.log(poke2.nivel);