const pokemons = [
  { nombre: "Pikachu", nivel: 25, tipo: "eléctrico" },
  { nombre: "Eevee", nivel: 18, tipo: "normal" },
  { nombre: "Bulbasaur", nivel: 12, tipo: "planta" },
  { nombre: "Voltorb", nivel: 10, tipo: "eléctrico" },
];

const esPokemonFuerte = (poke) => {
  return poke.nivel > 15;
};

const noEsPokemonElectrico = (poke) => {
  return poke.tipo != "eléctrico";
};

const convierteMayusculas = (poke) => {
  return { ...poke, nombre: poke.nombre.toUpperCase() };
};

const resultado = pokemons
  .filter(esPokemonFuerte)
  .filter(noEsPokemonElectrico)
  .map(convierteMayusculas);

console.log(resultado);

let resultado2 = [];

pokemons.forEach((poke) => {
  if (esPokemonFuerte(poke) && noEsPokemonElectrico(poke)) {
    resultado2.push(poke);
  }
});

console.log(resultado2);

resultado2 = [];

for (let poke of pokemons) {
  if (esPokemonFuerte(poke)) {
    resultado2.push(poke);
  }
}

console.log(resultado2);
