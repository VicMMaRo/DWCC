class Pokemon {
  #hp;

  constructor(nombre, tipo, hp) {
    this.nombre = nombre;
    this.tipo = tipo;
    this.#hp = hp;
  }

  atacar(objetivo) {
    console.log(`${this.nombre} ataca a ${objetivo.nombre}!`);
  }

  recibirDano(dano) {
    this.#hp -= dano;
    if (this.#hp < 0) this.#hp = 0;
    console.log(`${this.nombre} ahora tiene ${this.#hp} HP.`);
  }

  getHP() {
    return this.#hp;
  }

  static lema() {
    console.log("¡Gotta catch ’em all! 🏆");
  }
}