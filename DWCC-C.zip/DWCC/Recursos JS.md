## Documentación:

- https://developer.mozilla.org/es/docs/Web/JavaScript
- https://tc39.es/ecma262/

## Tutoriales:

- https://es.javascript.info/
- https://eloquentjavascript.net/

## Cursos:

- https://www.freecodecamp.org/
- https://www.theodinproject.com/
- https://www.codecademy.com/

## ¿Qué tecnologías son interesantes para un determinado perfil de programador@?

- https://roadmap.sh/

## Ejercicios/Retos:

- https://www.codewars.com/
- https://exercism.org/tracks/javascript
- https://www.frontendmentor.io/

## Herramientas Interesantes:

- https://codesandbox.io/
- https://jsfiddle.net/
- https://regex101.com/

## Generadores IA:

- https://stackblitz.com/
- https://replit.com/

## Inspiración Actualidad:

- https://www.30secondsofcode.org/

## Youtube:

- https://www.youtube.com/@theavocoder
- https://www.youtube.com/@TraversyMedia
- https://www.youtube.com/@FaztCode
- https://www.youtube.com/@midudev
- https://www.youtube.com/@mouredev
