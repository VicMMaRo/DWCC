let texto = "Ola, chámome Sinchan e teño cinco anos";
let primerCaracter = texto[0];
let ultimoCaracter = texto[texto.length-1];

console.log(`Primer Caracter -> ${primerCaracter} | Ultimo Caracter -> ${ultimoCaracter}`);

console.log(texto.toUpperCase);
console.log(texto.toLowerCase);

console.log(texto.replaceAll(' ','-'));

for (let index = 0; index < texto.length; index++) {
    const letra = texto[index];
    console.log(letra);
}